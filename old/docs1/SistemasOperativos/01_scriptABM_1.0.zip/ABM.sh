#!/bin/bash

opc=null
docUsu=/home/informix/usuarios/usuarios
docProvi=/home/informix/usuarios/txtProvi
clear
while [ "$opc" != 0 ]
do
echo "---------------------------"
echo "--- GESTIÓN DE USUARIOS ---"
echo "---------------------------"
echo "- Elija la opción deseada -"
echo "---------------------------"
echo ""
echo "1) Alta de usuario"
echo "2) Modificar un usuario"
echo "3) Baja de usuario"
echo "4) Ver listado de usuarios"
echo "0) Salir"
read opc
clear
case $opc in
1)
echo "----------------"
echo "Alta de Usuario"
echo "----------------"
echo ""
echo "Escriba un nombre (real)"
read nom
echo ""
echo "Escriba un apellido (real)"
read ape
echo ""
#echo "Escriba una dirección"
#read dire
echo "Escriba una cédula"
read ci
evalCI=$(cat $docUsu | grep $ci)
while [ $evalCI ]
do
echo "La cédula ya existe, inténtelo de nuevo"
read ci
evalCI=$(cat $docUsu | grep $ci)
done
echo ""
echo "Escriba un teléfono"
read tel
echo ""
echo "Ingrese el Nombre de Usuario"
read usu
echo ""
echo "Ingrese una contraseña"
read pass
nuevoUser=$ci:$usu:$pass:$nom:$ape:$tel
eval=$(cat $docUsu | grep $nuevoUser)
if [ -z $eval ]
then
echo $nuevoUser>>$docUsu
echo ""
echo "El usuario ha sido creado exitosamente"
else
echo "El usuario ya existe"
fi
echo "Presiona enter para continuar..."
read opc
clear
;;
2)
echo
echo "--------------------------------------"
echo "-- Modificación de datos de Usuario --"
echo "--------------------------------------"
echo ""
echo "Ingrese una cédula"
read ci
evalUser=$(cat $docUsu | grep $ci)
if [ $evalUser ]
then
echo $evalUser > $docProvi
echo ""
cat $docProvi
echo ""
echo "Ingrese la info existente que quiere cambiar"
read dato1
while [ $dato1 = $ci ]
do
echo ""
echo "La CI no puede modificarse, inténtelo de nuevo"
read dato1
done
echo ""
echo "Ingrese la info nueva"
read dato2
sed -i 's/'"$dato1"'/'"$dato2"'/g' $docProvi
read datoProvi < $docProvi
sed -i 's/'"$evalUser"'/'"$datoProvi"'/g' $docUsu
echo "" > $datoProvi
echo ""
echo "¡Cambios realizados!"
else
echo ""
echo "El usuario no existe"
fi
echo "Presiona enter para continuar..."
read opc
clear
;;
3)
echo "---------------------"
echo "-- Baja de Usuario --"
echo "---------------------"
echo ""
echo "Ingrese una cédula"
read ci
#evalUser=$(cat usuarios | grep $ci | cut -d ":" -f 1)
evalUser=$(cat $docUsu | grep -n $ci | cut -d ":" -f 1)
#evalUser2=$(cat usuarios | grep $ci | cut -d)
if [ -z $evalUser ]
then
echo "El usuario no existe"
else
hola= sed ''"$evalUser"'d' $docUsu>>$docProvi
echo "" > $docUsu
cat $docProvi>$docUsu
echo "" > $docProvi
echo "Baja exitosa"
fi
echo ""
echo "Presiona enter para continuar..."
read opc
clear
;;
4)
echo "-------------------------"
echo "-- Listado de usuarios --"
echo "-------------------------"
echo ""
cat $docUsu
echo ""
echo "Presiona enter para continuar..."
read opc
clear
;;
0)
break
;;
*) echo "La opción es incorrecta"
sleep 1
clear;;
esac
done
echo "-------------"
echo "-- THE END --"
echo "-------------"
echo ""
echo "Presiona enter para continuar"
read opc
clear
exit
